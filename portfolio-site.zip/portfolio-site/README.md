# Balasankar S — Portfolio Website

> Personal portfolio of **Balasankar S** — First-year ECE student at SBCE Kerala, founder of KrishEdge agritech startup, Junior Executive at Nuke Lab, and YIP 8.0 District Winner.

🌐 **Live site:** `https://your-username.github.io/portfolio` *(update after deploying)*

---

## 🗂️ Project Structure

```
portfolio/
├── index.html              ← Main HTML file
├── assets/
│   ├── css/
│   │   └── style.css       ← All styles
│   ├── js/
│   │   └── main.js         ← Scroll animations, interactions
│   ├── images/
│   │   ├── hero.jpg        ← Profile photo (hero section)
│   │   └── campus.jpg      ← Campus photo (gallery section)
│   └── favicon.svg         ← Browser tab icon
└── README.md
```

---

## 🚀 Deploy to GitHub Pages (Step-by-Step)

### Step 1 — Create a GitHub Repository
1. Go to [github.com](https://github.com) and sign in
2. Click **"New repository"**
3. Name it: `portfolio` (or `your-username.github.io` for a root domain)
4. Set to **Public**
5. Click **"Create repository"**

### Step 2 — Upload Files
**Option A — GitHub Web UI (easiest from mobile):**
1. Open your new repo
2. Click **"uploading an existing file"**
3. Upload all files maintaining the folder structure:
   - `index.html`
   - `assets/css/style.css`
   - `assets/js/main.js`
   - `assets/images/hero.jpg`
   - `assets/images/campus.jpg`
   - `assets/favicon.svg`
4. Click **"Commit changes"**

**Option B — Git CLI:**
```bash
git init
git add .
git commit -m "Initial portfolio deploy"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/portfolio.git
git push -u origin main
```

### Step 3 — Enable GitHub Pages
1. Go to your repo → **Settings** → **Pages** (left sidebar)
2. Under **"Source"**, select **"Deploy from a branch"**
3. Branch: `main` | Folder: `/ (root)`
4. Click **Save**
5. Wait ~2 minutes, then visit: `https://YOUR_USERNAME.github.io/portfolio`

---

## ✏️ Customization

| What to change | Where |
|---|---|
| Your name, bio, description | `index.html` — hero section |
| Profile photo | Replace `assets/images/hero.jpg` |
| Campus photo | Replace `assets/images/campus.jpg` |
| Colors / fonts | `assets/css/style.css` — `:root` variables |
| Projects, achievements | `index.html` — respective sections |
| Contact links (email, LinkedIn) | `index.html` — contact section |

---

## 🛠️ Tech Stack

- **HTML5** — semantic structure
- **CSS3** — custom properties, grid, animations
- **Vanilla JS** — IntersectionObserver, scroll effects
- **Google Fonts** — JetBrains Mono, Space Grotesk, Syne
- **GitHub Pages** — free hosting

---

## 📄 License

© 2026 Balasankar S. All rights reserved.
