// ============================================
//  BALASANKAR S — Portfolio JS
//  ECE Student · Entrepreneur · Nuke Lab
// ============================================

// Fade-up on scroll
const observer = new IntersectionObserver((entries) => {
  entries.forEach(e => {
    if (e.isIntersecting) e.target.classList.add('visible');
  });
}, { threshold: 0.1 });

document.querySelectorAll('.fade-up').forEach(el => observer.observe(el));

// Skill bar animation on scroll
const barObserver = new IntersectionObserver((entries) => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      e.target.querySelectorAll('.skill-bar-fill').forEach(bar => {
        bar.style.animation = 'none';
        bar.offsetHeight; // force reflow
        bar.style.animation = 'fillBar 1.4s ease forwards';
      });
    }
  });
}, { threshold: 0.3 });

document.querySelectorAll('.skills-grid').forEach(el => barObserver.observe(el));

// Active nav link highlight on scroll
const sections = document.querySelectorAll('section[id]');
const navLinks = document.querySelectorAll('.nav-links a');

const sectionObserver = new IntersectionObserver((entries) => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      navLinks.forEach(link => {
        link.style.color = '';
        if (link.getAttribute('href') === '#' + e.target.id) {
          link.style.color = 'var(--accent)';
        }
      });
    }
  });
}, { threshold: 0.4 });

sections.forEach(s => sectionObserver.observe(s));

// Typing cursor blink in terminal header
const termTitle = document.querySelector('.terminal-title');
if (termTitle) {
  let visible = true;
  setInterval(() => {
    visible = !visible;
    termTitle.style.borderRight = visible ? '2px solid rgba(0,212,255,0.6)' : '2px solid transparent';
  }, 530);
}
